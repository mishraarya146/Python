# Campus Lost & Found Management System

Course: Computational Thinking & Programming (2026CSAE100) - Bennett University, B.Tech CSE (AI & ML)

A Python system to record, search and match lost and found items on campus. It comes in two forms that share the same code:

- **Console app** - `main.py`
- **Web interface** - `app.py` (Flask)

## Features
- Login (hashed passwords)
- Add / view / delete lost items and found items, with input validation
- Mark items as claimed
- Search by keyword, category, location and date range
- **Weighted matching** - `Score = Category x 0.40 + Location x 0.35 + Keyword x 0.25`; scores >= 0.60 are flagged for review (no machine learning)
- Summary report (counts, items by category, top lost locations)
- CSV storage in `data/` so records persist

## How to run
```bash
pip install -r requirements.txt     # only needed for the website

python main.py                      # console version (no install needed)
python app.py                       # website -> open http://127.0.0.1:5000
python -m unittest discover tests   # run the tests
```
Demo logins: `admin / admin123` or `student / student123`.

Optional environment variables for the website: `SECRET_KEY` (session key) and `FLASK_DEBUG=1` (auto-reload while developing).

## Deploy on the web
- **PythonAnywhere (free, keeps CSV data):** clone this repo in a Bash console, create a virtualenv, `pip install -r requirements.txt`, add a Flask web app pointing to `app.py`, and set `SECRET_KEY`.
- **Render (free):** New Web Service from the GitHub repo, build command `pip install -r requirements.txt`, start command `gunicorn app:app`, env var `SECRET_KEY`. Note: free Render storage is temporary, so CSV changes reset on redeploy or restart.

## Project structure
```
main.py            console interface
app.py             web interface (Flask routes)
modules/
  auth.py          login                         (Sahil)
  items.py         add / view / delete / search  (Aarav Rathore - lost, Arya Mishra - found)
  matching.py      weighted matching             (Siddhi Soni)
  report.py        report generation             (Siddhi Soni)
  storage.py       CSV read / write              (Pratik Vishal)

data/              lost_items.csv, found_items.csv (sample records)
tests/             unit tests (TC01-TC05 and more)
```

## Team
| Name | Enrollment | Role |
|---|---|---|
| Sahil | S26CSEU3568 | Project Lead - Login & Main Menu |
| Aarav Rathore | S26CSEU3587 | Lost Item Module |
| Arya Mishra | S26CSEU3567 | Found Item Module |
| Siddhi Soni | S26CSEU3540 | Search, Matching & Report |
| Pratik Vishal | S26CSEU3525 | CSV Handling, Testing, Documentation |

## Future improvements
SQLite database, role-based access, image uploads, notifications, more filters.
