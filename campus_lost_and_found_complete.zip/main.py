"""Campus Lost & Found Management System - console version.
Run with:  python main.py"""
from modules.auth import check_login
from modules.items import CATEGORIES, add_item, get_items, delete_item, update_status, search_items
from modules.matching import find_matches
from modules.report import report_text
import getpass


def login():
    for attempt in range(3):
        user = input("Username: ")
        pwd = getpass.getpass("Password: ")
        if check_login(user, pwd):
            print(f"\nWelcome, {user}!")
            return True
        print(f"Invalid login. {2 - attempt} attempt(s) left.")
    return False


def show(records):
    if not records:
        print("  No records found.")
        return
    for r in records:
        print(f"  [{r['id']}] {r['item_name']} | {r['category']} | {r['location']} | "
              f"{r['date']} | {r['status']}")
        if r["description"]:
            print(f"       {r['description']}")


def ask_item(kind):
    print(f"\n--- Report {kind.title()} Item ---")
    print("Categories:", ", ".join(f"{i + 1}={c}" for i, c in enumerate(CATEGORIES)))
    data = {"item_name": input("Item name: "), "location": input("Location: "),
            "date": input("Date (YYYY-MM-DD): "), "description": input("Description: "),
            "contact": input("Contact: ")}
    try:
        data["category"] = CATEGORIES[int(input("Category number: ")) - 1]
    except (ValueError, IndexError):
        data["category"] = ""
    ok, result = add_item(kind, data)
    print("Saved successfully!" if ok else "Error:\n  " + "\n  ".join(result))


def ask_id(prompt):
    try:
        return int(input(prompt))
    except ValueError:
        print("Please enter a number.")
        return None


def search():
    kind = input("Search (1) lost or (2) found? ").strip()
    kind = "lost" if kind == "1" else "found"
    show(search_items(kind, input("Keyword (blank=any): "),
                      location=input("Location (blank=any): ")))


def matches():
    found = find_matches()
    if not found:
        print("No possible matches found.")
    for m in found:
        print(f"  Score {m['score']:.2f}: LOST '{m['lost']['item_name']}' <-> "
              f"FOUND '{m['found']['item_name']}'  -> Flagged for Review")


MENU = """
===== CAMPUS LOST & FOUND =====
1. Report lost item      6. Delete lost item
2. Report found item     7. Delete found item
3. View lost items       8. Search records
4. View found items      9. Find possible matches
5. Mark item claimed    10. Generate report
0. Exit"""


def main():
    if not login():
        print("Too many failed attempts.")
        return
    while True:
        print(MENU)
        choice = input("Choose: ").strip()
        if choice == "1":
            ask_item("lost")
        elif choice == "2":
            ask_item("found")
        elif choice == "3":
            show(get_items("lost"))
        elif choice == "4":
            show(get_items("found"))
        elif choice == "5":
            kind = "lost" if input("(1) lost or (2) found? ").strip() == "1" else "found"
            i = ask_id("Item id: ")
            if i is not None:
                print("Updated." if update_status(kind, i, "Claimed") else "ID not found.")
        elif choice in ("6", "7"):
            i = ask_id("Item id to delete: ")
            if i is not None:
                print("Deleted." if delete_item("lost" if choice == "6" else "found", i) else "ID not found.")
        elif choice == "8":
            search()
        elif choice == "9":
            matches()
        elif choice == "10":
            print(report_text())
        elif choice == "0":
            print("Goodbye!")
            break
        else:
            print("Invalid choice, try again.")


if __name__ == "__main__":
    main()
