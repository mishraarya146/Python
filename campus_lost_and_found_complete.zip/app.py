"""Campus Lost & Found Management System - Flask web interface.
Run with:  python app.py"""
import os
from functools import wraps
from flask import Flask, flash, redirect, render_template, request, session, url_for

from modules.auth import check_login
from modules.items import CATEGORIES, add_item, delete_item, get_items, search_items, update_status
from modules.matching import find_matches
from modules.report import build_report

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "campus-lost-and-found-dev-key")


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user" not in session:
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


@app.route("/")
def index():
    return redirect(url_for("items", kind="lost") if "user" in session else url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        user = request.form.get("username", "").strip()
        pwd = request.form.get("password", "")
        if check_login(user, pwd):
            session["user"] = user
            flash(f"Welcome back, {user}!", "ok")
            return redirect(url_for("items", kind="lost"))
        flash("Invalid username or password.", "err")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/items/<kind>")
@login_required
def items(kind):
    if kind not in ("lost", "found"):
        return redirect(url_for("items", kind="lost"))
    return render_template("items.html", kind=kind, items=get_items(kind))


@app.route("/add/<kind>", methods=["GET", "POST"])
@login_required
def add(kind):
    if kind not in ("lost", "found"):
        return redirect(url_for("items", kind="lost"))
    form_data = {}
    if request.method == "POST":
        form_data = {
            "item_name": request.form.get("item_name", ""),
            "category": request.form.get("category", ""),
            "location": request.form.get("location", ""),
            "date": request.form.get("date", ""),
            "description": request.form.get("description", ""),
            "contact": request.form.get("contact", ""),
        }
        ok, res = add_item(kind, form_data)
        if ok:
            flash(f"{kind.title()} item reported.", "ok")
            return redirect(url_for("items", kind=kind))
        for err in res:
            flash(err, "err")
    return render_template("add.html", kind=kind, categories=CATEGORIES, data=form_data)


@app.route("/claim/<kind>/<int:item_id>", methods=["POST"])
@login_required
def claim(kind, item_id):
    if update_status(kind, item_id, "Claimed"):
        flash("Item marked as Claimed.", "ok")
    return redirect(url_for("items", kind=kind))


@app.route("/delete/<kind>/<int:item_id>", methods=["POST"])
@login_required
def delete(kind, item_id):
    if delete_item(kind, item_id):
        flash("Item deleted.", "ok")
    return redirect(url_for("items", kind=kind))


@app.route("/search")
@login_required
def search():
    q = request.args
    kind = q.get("kind", "lost")
    if kind not in ("lost", "found"):
        kind = "lost"
    results = None
    if any(q.get(k) for k in ("keyword", "category", "location", "date_from", "date_to", "kind")):
        results = search_items(
            kind=kind,
            keyword=q.get("keyword", ""),
            category=q.get("category", ""),
            location=q.get("location", ""),
            date_from=q.get("date_from", ""),
            date_to=q.get("date_to", ""),
        )
    return render_template("search.html", kind=kind, q=q, categories=CATEGORIES, results=results)


@app.route("/matches")
@login_required
def matches():
    return render_template("matches.html", matches=find_matches())


@app.route("/report")
@login_required
def report():
    return render_template("report.html", rep=build_report())


if __name__ == "__main__":
    debug = os.environ.get("FLASK_DEBUG", "0") == "1"
    app.run(debug=debug)
