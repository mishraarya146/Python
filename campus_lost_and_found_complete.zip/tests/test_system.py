import os
import tempfile
import unittest
from unittest.mock import patch

from modules import storage
from modules.auth import check_login
from modules.items import add_item, delete_item, get_items, search_items, update_status
from modules.matching import find_matches
from modules.report import build_report


class TestCampusLostAndFound(unittest.TestCase):
    def setUp(self):
        self.tmp_dir = tempfile.TemporaryDirectory()
        self.patcher = patch.object(storage, "DATA_DIR", self.tmp_dir.name)
        self.patcher.start()

    def tearDown(self):
        self.patcher.stop()
        self.tmp_dir.cleanup()

    def test_tc01_login(self):
        self.assertTrue(check_login("admin", "admin123"))
        self.assertTrue(check_login("student", "student123"))
        self.assertFalse(check_login("admin", "wrong"))

    def test_tc02_add_and_validate_item(self):
        ok, err = add_item("lost", {"item_name": ""})
        self.assertFalse(ok)
        self.assertTrue(len(err) > 0)

        ok, item = add_item("lost", {
            "item_name": "AirPods Pro",
            "category": "Electronics",
            "location": "Sports Complex",
            "date": "2026-11-25",
            "description": "White case",
            "contact": "test@bennett.edu.in",
        })
        self.assertTrue(ok)
        self.assertEqual(item["item_name"], "AirPods Pro")

    def test_tc03_search_and_status(self):
        results = search_items("lost", keyword="Charger")
        self.assertEqual(len(results), 1)
        self.assertTrue(update_status("lost", results[0]["id"], "Claimed"))
        updated = [r for r in get_items("lost") if r["id"] == results[0]["id"]][0]
        self.assertEqual(updated["status"], "Claimed")

    def test_tc04_weighted_matching(self):
        matches = find_matches(threshold=0.60)
        self.assertTrue(len(matches) >= 1)
        self.assertGreaterEqual(matches[0]["score"], 0.60)

    def test_tc05_delete_and_report(self):
        rep = build_report()
        self.assertIn("lost_total", rep)
        self.assertTrue(delete_item("found", 2))
        self.assertFalse(delete_item("found", 999))


if __name__ == "__main__":
    unittest.main()
