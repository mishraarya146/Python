"""Weighted matching engine:
Score = Category * 0.40 + Location * 0.35 + Keyword * 0.25
Scores >= 0.60 are flagged for manual review."""
import re
from modules.items import get_items


def _tokens(text: str) -> set[str]:
    return set(re.findall(r"[a-z0-9]+", text.lower()))


def compute_score(lost: dict, found: dict) -> float:
    cat_score = 1.0 if lost["category"] == found["category"] else 0.0

    lost_loc = _tokens(lost["location"])
    found_loc = _tokens(found["location"])
    if lost["location"].strip().lower() == found["location"].strip().lower():
        loc_score = 1.0
    elif lost_loc and found_loc:
        loc_score = len(lost_loc & found_loc) / len(lost_loc | found_loc)
    else:
        loc_score = 0.0

    lost_kw = _tokens(f"{lost['item_name']} {lost['description']}")
    found_kw = _tokens(f"{found['item_name']} {found['description']}")
    if lost_kw and found_kw:
        kw_score = len(lost_kw & found_kw) / len(lost_kw | found_kw)
    else:
        kw_score = 0.0

    return round(cat_score * 0.40 + loc_score * 0.35 + kw_score * 0.25, 4)


def find_matches(threshold: float = 0.60) -> list[dict]:
    lost_open = [r for r in get_items("lost") if r["status"] == "Open"]
    found_open = [r for r in get_items("found") if r["status"] == "Open"]

    matches = []
    for l_item in lost_open:
        for f_item in found_open:
            score = compute_score(l_item, f_item)
            if score >= threshold:
                matches.append({"lost": l_item, "found": f_item, "score": score})

    matches.sort(key=lambda m: m["score"], reverse=True)
    return matches
