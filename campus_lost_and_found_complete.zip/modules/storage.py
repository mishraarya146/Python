"""CSV storage layer for lost and found items."""
import csv
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")

FIELDS = ["id", "item_name", "category", "location", "date", "description", "contact", "status"]

DEFAULT_LOST = [
    {"id": "1", "item_name": "Black Dell Laptop Charger", "category": "Electronics",
     "location": "Central Library", "date": "2026-11-20",
     "description": "65W USB-C charger with blue velcro strap", "contact": "aarav@bennett.edu.in", "status": "Open"},
    {"id": "2", "item_name": "Blue Hydro Flask Bottle", "category": "Accessories",
     "location": "Block A Cafeteria", "date": "2026-11-22",
     "description": "32oz insulated bottle with Bennett sticker", "contact": "arya@bennett.edu.in", "status": "Open"},
    {"id": "3", "item_name": "Student ID Card - Sahil", "category": "ID & Cards",
     "location": "Lecture Hall 3", "date": "2026-11-24",
     "description": "B.Tech CSE ID card in clear holder", "contact": "sahil@bennett.edu.in", "status": "Claimed"},
]

DEFAULT_FOUND = [
    {"id": "1", "item_name": "Dell USB-C Laptop Charger", "category": "Electronics",
     "location": "Central Library", "date": "2026-11-21",
     "description": "Black 65W charger left on 2nd floor table", "contact": "library-desk@bennett.edu.in", "status": "Open"},
    {"id": "2", "item_name": "Scientific Calculator fx-991EX", "category": "Stationery & Books",
     "location": "Block B Lab 2", "date": "2026-11-23",
     "description": "Casio Classwiz found near PC 14", "contact": "lab-support@bennett.edu.in", "status": "Open"},
]


def _file_path(kind: str) -> str:
    os.makedirs(DATA_DIR, exist_ok=True)
    filename = "lost_items.csv" if kind == "lost" else "found_items.csv"
    path = os.path.join(DATA_DIR, filename)
    if not os.path.exists(path):
        seed = DEFAULT_LOST if kind == "lost" else DEFAULT_FOUND
        write_records(kind, seed)
    return path


def read_records(kind: str) -> list[dict]:
    path = _file_path(kind)
    with open(path, mode="r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = []
        for row in reader:
            row["id"] = int(row["id"])
            rows.append(row)
        return rows


def write_records(kind: str, records: list[dict]) -> None:
    os.makedirs(DATA_DIR, exist_ok=True)
    filename = "lost_items.csv" if kind == "lost" else "found_items.csv"
    path = os.path.join(DATA_DIR, filename)
    with open(path, mode="w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader()
        for r in records:
            row = {k: r.get(k, "") for k in FIELDS}
            writer.writerow(row)
