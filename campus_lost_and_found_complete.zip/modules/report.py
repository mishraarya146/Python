"""Summary report generation for console and web."""
from collections import Counter
from datetime import datetime
from modules.items import get_items
from modules.matching import find_matches


def build_report() -> dict:
    lost = get_items("lost")
    found = get_items("found")
    all_items = lost + found

    by_category = Counter(r["category"] for r in all_items).most_common()
    top_locations = Counter(r["location"] for r in lost).most_common(5)

    return {
        "generated": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "lost_total": len(lost),
        "lost_open": sum(1 for r in lost if r["status"] == "Open"),
        "found_total": len(found),
        "found_open": sum(1 for r in found if r["status"] == "Open"),
        "claimed": sum(1 for r in all_items if r["status"] == "Claimed"),
        "possible_matches": len(find_matches()),
        "by_category": by_category,
        "top_locations": top_locations,
    }


def report_text() -> str:
    rep = build_report()
    lines = [
        f"===== SUMMARY REPORT ({rep['generated']}) =====",
        f"Lost items:       {rep['lost_total']} ({rep['lost_open']} open)",
        f"Found items:      {rep['found_total']} ({rep['found_open']} open)",
        f"Claimed items:    {rep['claimed']}",
        f"Possible matches: {rep['possible_matches']}",
        "
Items by category:",
    ]
    for cat, count in rep["by_category"]:
        lines.append(f"  - {cat}: {count}")
    lines.append("
Top places items are lost:")
    for loc, count in rep["top_locations"]:
        lines.append(f"  - {loc}: {count}")
    return "
".join(lines)
