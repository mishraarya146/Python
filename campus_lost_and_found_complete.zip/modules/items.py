"""CRUD operations, validation, and filtering for lost and found records."""
from datetime import datetime
from modules.storage import read_records, write_records

CATEGORIES = [
    "Electronics",
    "ID & Cards",
    "Accessories",
    "Stationery & Books",
    "Clothing",
    "Keys & Wallets",
    "Other",
]


def validate_item(data: dict) -> list[str]:
    errors = []
    if not str(data.get("item_name", "")).strip():
        errors.append("Item name is required.")
    if data.get("category") not in CATEGORIES:
        errors.append("Please select a valid category.")
    if not str(data.get("location", "")).strip():
        errors.append("Location is required.")
    date_str = str(data.get("date", "")).strip()
    try:
        datetime.strptime(date_str, "%Y-%m-%d")
    except ValueError:
        errors.append("Date must be in YYYY-MM-DD format.")
    if not str(data.get("contact", "")).strip():
        errors.append("Contact info is required.")
    return errors


def get_items(kind: str) -> list[dict]:
    return read_records(kind)


def add_item(kind: str, data: dict):
    errors = validate_item(data)
    if errors:
        return False, errors
    records = read_records(kind)
    next_id = max((r["id"] for r in records), default=0) + 1
    new_record = {
        "id": next_id,
        "item_name": data["item_name"].strip(),
        "category": data["category"].strip(),
        "location": data["location"].strip(),
        "date": data["date"].strip(),
        "description": str(data.get("description", "")).strip(),
        "contact": data["contact"].strip(),
        "status": "Open",
    }
    records.append(new_record)
    write_records(kind, records)
    return True, new_record


def delete_item(kind: str, item_id: int) -> bool:
    records = read_records(kind)
    updated = [r for r in records if r["id"] != item_id]
    if len(updated) == len(records):
        return False
    write_records(kind, updated)
    return True


def update_status(kind: str, item_id: int, status: str) -> bool:
    records = read_records(kind)
    found = False
    for r in records:
        if r["id"] == item_id:
            r["status"] = status
            found = True
            break
    if found:
        write_records(kind, records)
    return found


def search_items(kind: str, keyword: str = "", category: str = "",
                 location: str = "", date_from: str = "", date_to: str = "") -> list[dict]:
    records = read_records(kind)
    kw = keyword.strip().lower()
    cat = category.strip()
    loc = location.strip().lower()
    df = date_from.strip()
    dt = date_to.strip()

    results = []
    for r in records:
        if kw and kw not in r["item_name"].lower() and kw not in r["description"].lower():
            continue
        if cat and r["category"] != cat:
            continue
        if loc and loc not in r["location"].lower():
            continue
        if df and r["date"] < df:
            continue
        if dt and r["date"] > dt:
            continue
        results.append(r)
    return results
