"""Authentication module using SHA-256 password hashing."""
import hashlib

def _hash(password: str) -> str:
    return hashlib.sha256(password.encode("utf-8")).hexdigest()

USERS = {
    "admin": _hash("admin123"),
    "student": _hash("student123"),
}

def check_login(username: str, password: str) -> bool:
    if not username or not password:
        return False
    expected = USERS.get(username.strip())
    return expected is not None and expected == _hash(password)
